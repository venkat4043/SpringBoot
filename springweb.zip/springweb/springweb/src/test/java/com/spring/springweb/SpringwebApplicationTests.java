package com.spring.springweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
